# Slyk7dayFiles

scripts to download KiddaC Slyk7day EPG files
